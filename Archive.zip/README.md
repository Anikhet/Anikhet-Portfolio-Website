Developed a web page to display my projects! All the code has been written from scratch without help of AI .
